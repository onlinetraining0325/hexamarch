<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<form action="demoresult">
		<center>
			Name : 
			<input type="text" name="sname" /> <br/> <br/>
			<input type="submit" value="Show" />
		</center> 
	</form>
</body>
</html>