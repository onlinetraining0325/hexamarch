package com.java.aop;

public class JavaFsdTraining {

	public void showInfo(String batch2) {
		System.out.println("Java FSD Training is Happening for Batch2...");
	}
	
	public void location() {
		System.out.println("Its for Online Training...");
	}
}
